
package iokeeffepatient;

/**
 *
 * @author Isabelle OKeeffe
 */
public class IOKEEFFEPATIENTTEST 
{

    
    public static void main(String[] args)
    {
   
     Patient pat1= new Patient(); //Default Constructor
        pat1.setName("Ana Amari");
        pat1.setHeight(1.4);
        pat1.setWeight(50);
        pat1.setdateofBirth(new Date(3,9,1965));
        
        
        
     Patient pat2= new Patient(); //Patient 2
        pat2.setName("Jack Morrison");
        pat2.setHeight(2.2);
        pat2.setWeight(200);
        pat2.setdateofBirth(new Date (5,5,1963));
                
                
        
     Patient pat3= new Patient();//patient 3
        pat3.setName("Hana Song");
        pat3.setHeight(1.5);
        pat3.setWeight(47);
        pat3.setdateofBirth(new Date(12,23,1997));
        
        
     Patient pat4= new Patient("Genji Shimada",2.0,82,new Date(11,22,1994)); //patient 4 shows that  constructor 2 works   
        
                
     Patient pat5= new Patient("Mei-Ling Zhou",3.0,250,new Date(1,1,1987)); //patient 5 shows that  constructor 2 works   
     
     
     Patient pat6= new Patient("Torbjorn Lindholm",1.0,56, new Date(10,5,1972)); //patient 5 shows that  constructor 2 works   
              
        
        //Printed Details of Patient1
        System.out.println("--The Details for Patient 1 are--");
        System.out.println("Name: "+pat1.getName());
        System.out.println("Date Of Birth: "+pat1.getdateofBirth().toDateString());
        System.out.println("Height (M): "+pat1.getHeight());
        System.out.println("Weight (KG): "+pat1.getWeight());
        System.out.println("The Body Mass Index for "+pat1.getName()+" is "+pat1.calcBMI()+" they are classed as "+pat1.bodymassindex());
        
        //Printed Details of Patient2
        System.out.println("--The Details for Patient 2 are--");
        System.out.println("Name: "+pat2.getName());
        System.out.println("Date Of Birth: "+pat2.getdateofBirth().toDateString());
        System.out.println("Height (M): "+pat2.getHeight());
        System.out.println("Weight (KG): "+pat2.getWeight());
        System.out.println("The Body Mass Index for "+pat2.getName()+" is "+pat2.calcBMI()+" they are classed as "+pat2.bodymassindex());
        
        //Printed Details of Patient3
        System.out.println("--The Details for Patient 3 are--");
        System.out.println("Name: "+pat3.getName());
        System.out.println("Date Of Birth: "+pat3.getdateofBirth().toDateString());
        System.out.println("Height (M): "+pat3.getHeight());
        System.out.println("Weight (KG): "+pat3.getWeight());
        System.out.println("The Body Mass Index for "+pat3.getName()+" is " +pat3.calcBMI()+" they are classed as "+pat3.bodymassindex());
        
        //Printed Details of Patient4
        System.out.println("--The Details for Patient 4 are--");
        System.out.println("Name: "+pat4.getName());
        System.out.println("Date Of Birth: "+pat4.getdateofBirth().toDateString());
        System.out.println("Height (M): "+pat4.getHeight());
        System.out.println("Weight (KG): "+pat4.getWeight());
        System.out.println("The Body Mass Index for "+pat4.getName()+" is " +pat4.calcBMI()+" they are classed as "+pat4.bodymassindex());
        
        //Printed Details of Patient5 
        System.out.println("--The Details for Patient 5 are--");
        System.out.println("Name: "+pat5.getName());
        System.out.println("Date Of Birth: "+pat5.getdateofBirth().toDateString());
        System.out.println("Height (M): "+pat5.getHeight());
        System.out.println("Weight (KG): "+pat5.getWeight());
        System.out.println("The Body Mass Index for "+pat5.getName()+" is " +pat5.calcBMI()+" they are classed as "+pat5.bodymassindex());
        
        //Printed Details of Patient6 
        System.out.println("--The Details for Patient 6 are--");
        System.out.println("Name: "+pat6.getName());
        System.out.println("Date Of Birth: "+pat6.getdateofBirth().toDateString());
        System.out.println("Height (M): "+pat6.getHeight());
        System.out.println("Weight (KG): "+pat6.getWeight());
        System.out.println("The Body Mass Index for "+pat6.getName()+" is " +pat6.calcBMI()+" they are classed as "+pat6.bodymassindex());
    }
    
}
