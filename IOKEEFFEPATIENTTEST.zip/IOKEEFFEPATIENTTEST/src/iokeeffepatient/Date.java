
package iokeeffepatient;

/**
 *
 * @author Brian Smith
 */
public class Date 
{


private int month;

private int day;

private int year;

/**

* Constructor for objects of class Date

*/

//constructor: confirm proper vaule for month;

//call method function checkDay to confirm proper value for day.

public Date(int theMonth,int theDay,int theYear )

{

if (theMonth>0 && theMonth<=12){ //validates month

month=theMonth;

}

else{

month=1;

System.out.println("Month "+theMonth+" is invaild. Set month to 1.");

}

if (theYear>0){ //validates year

year=theYear;}

else{

year=1;

System.out.println("Year"+theYear+"is invaild.Set Year to 1.");

}

day=checkDay(theDay); //validates day

//System.out.println("Date object constructor for date"+toDateString());

}

// utilty method to confirm if the day vaule is vaild.

public int checkDay(int testDay)

{

int daysPerMonth[]={0,31,28,31,30,31,30,31,31,30,31,30,31};

// check if day is possible to occur in that month.

if (testDay>0 && testDay<= daysPerMonth[month])

{

return testDay;

}

//check if year is leap year

if ((month==2 && testDay==29 && year %400==0) || (year%4==0 && year% 100 !=0))

{

return testDay;

}

System.out.println("Day"+testDay+"invaild Set to day 1.");

return 1;

}

//incraeses day by 1 and checks if that will change month.

public void nextDay()

{

int testDay =day+1;

if (checkDay(testDay)==testDay){

day= testDay;

}

else{

day=1;

nextMonth();

}

}

//incraeses month by 1 and checks if that will change year.

public void nextMonth()

{

if(12==month){

year++;

month=month%12+1;

}

}


public String toDateString() //create a string in the format month/day/year.

{

return month+"/"+day+"/"+year; // returns mm/dd//yyyy

}

} //end of class Date
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

