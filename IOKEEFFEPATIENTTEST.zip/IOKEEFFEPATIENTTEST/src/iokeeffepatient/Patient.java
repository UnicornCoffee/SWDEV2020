
package iokeeffepatient;

/**
 *
 * @author Isabelle OKeeffe
 */
public class Patient 
      
{
 //private instance variables as required in uml diagram
  private String fullname;
  private Date dateofbirth;
  private double height;
  private double weight;
  private double massindex;
  private String bodymassindex;
  private int month;
  private int day;
  private int year;
  
          
    

public Patient() // Default Constructor pat1
{
fullname = "Ana Amari";
height = 1.40;
weight = 50;
month =3;
day=9;
year=1965;
       
}

public Patient(String fn, double h, double w, Date dob) //Constructor 2 for all patients.
{
fullname=fn;
height=h;
weight=w;
dateofbirth=dob;
}


//                                   -METHODS SECTION-

//SET AND GET FULL NAME

public void setName(String fn)
{
    
fullname=fn;

}

public String getName()
{
return fullname;

}

//SET AND GET DATE OF BIRTH

public void setdateofBirth(Date dob)
{

    dateofbirth=dob;

}

public Date getdateofBirth()
{

    return dateofbirth;

}

//SET AND GET HEIGHT

public void setHeight(double h)
{

    height=h;
    
}

public double getHeight()
{

    return height;
    
}

//SET AND GET WEIGHT
public void setWeight (double w)
{

    weight=w;
    
}

public double getWeight ()
{

    return weight;

}

  
public double calcBMI() //Calculates the patients BMI as a numerical value
{

    massindex = weight / (height * height);
    return massindex;



}

    
public String bodymassindex() //explains which BMI class the patient falls into
{

 if(massindex < 18.5)
 {
  return  "underweight.";
 }
 if(massindex >= 18.5 && massindex <25)
 {
   return "normal weight.";
 }
 if(massindex >=25 && massindex <30)
 {
   return "overweight.";
 }  
 if(massindex >=30)
 {       
   return  "obese.";      
 } 
 
return bodymassindex;

}

@Override
public String toString()
{
 String state = "Name = "+fullname+ " Height = "+height+" Weight = "+weight+" Date of Birth. = "+dateofbirth.toDateString();
 return state;
}


}